#!/bin/bash

# 1. Deploy de la aplicación en AWS utilizando Serverless
echo "Desplegando proyecto de Inti Luna en AWS usando serverless..."
serverless deploy

# Esperar 3 segundos para que la URL de la API HTTP esté lista
echo "Esperando que la URL de la API HTTP esté disponible..."
sleep 3

# 2. Llamar a una función para rellenar la base de datos con registros de prueba
echo "Insertando registros de prueba en la base de datos..."
#api_url=$(sls info --verbose | grep HttpApiUrl | awk '{print $2}')
api_url=$(sls info --verbose | awk '/HttpApiUrl/{print $2}')
python preload_using_endpoint.py "$api_url"
